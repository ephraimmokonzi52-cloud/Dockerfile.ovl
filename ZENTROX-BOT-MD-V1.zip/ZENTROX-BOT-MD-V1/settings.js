const settings = {
  packname: 'ZENTROX MD',
  author: 'STIVO-TECH',
  botName: "ZENTROX MD",
  botOwner: 'STIVO-TECH',
  phoneNumber: "237675048398",
  ownerNumber: '237675048398',
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20,
  storeWriteInterval: 10000,
  description: "ZENTROX MD — Bot WhatsApp en français, rapide, multi-device, créer par STIVO-TECH.",
  version: "1.0.0",
  channelLink: "https://whatsapp.com/channel/0029Vb6nKuV8vd1M1iBlWe2l",
  updateZipUrl: "https://github.com/STIVE-DEVX/ZENTROX-MD-main.zip",
  botPreview: "https://i.postimg.cc/Dz3mbLwc/bot-image-f-Of28PVl.jpg",

  // Carte globale
  adReply: {
    title: "ZENTROX BOT MD",
    body: "BY STIVO TECH",
    thumbnailUrl: 'https://i.postimg.cc/c4KWPt69/chatgpt-image-3-dec-2025-17-48-55-PQCmcx-Vn.jpg',
    sourceUrl: 'https://whatsapp.com/channel/0029Vb6nKuV8vd1M1iBlWe2l',
    mediaType: 1,
    mediaUrl: 'https://whatsapp.com/channel/0029Vb6nKuV8vd1M1iBlWe2l',
    renderLargerThumbnail: false
  },

  // Newsletter global (optionnel, utilisable dans toutes les commandes)
  newsletter: {
    newsletterJid: '120363401545196668@newsletter',
    newsletterName: 'ZENTROX MD',
    serverMessageId: -1
  }
};

module.exports = settings;